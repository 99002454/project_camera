package top.defaults.camera;

public interface Keys {

    String MODE = "mode";
    String ASPECT_RATIO = "aspect.ratio";
    String AUTO_FOCUS = "auto.focus";
    String FACING = "facing";
    String FLASH = "flash";
}
