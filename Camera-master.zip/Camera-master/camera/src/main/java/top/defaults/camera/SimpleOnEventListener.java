package top.defaults.camera;

public class SimpleOnEventListener implements Photographer.OnEventListener {
    @Override
    public void onDeviceConfigured() {

    }

    @Override
    public void onPreviewStarted() {

    }

    @Override
    public void onZoomChanged(float zoom) {

    }

    @Override
    public void onPreviewStopped() {

    }

    @Override
    public void onStartRecording() {

    }

    @Override
    public void onFinishRecording(String filePath) {

    }

    @Override
    public void onShotFinished(String filePath) {

    }

    @Override
    public void onError(Error error) {

    }
}
